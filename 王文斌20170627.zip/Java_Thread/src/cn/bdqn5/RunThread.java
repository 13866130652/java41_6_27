package cn.bdqn5;

public class RunThread implements Runnable {
	private int meters = 1000;
	private boolean fale = true;

	@Override
	public void run() {
		while (fale) {
			relay();
		}
	}

	public void relay() {
		synchronized (this) {
			if (meters <= 0) {
				System.out.println("��������ɡ���������");
				fale = false;
				return;
			}

			System.out.println(Thread.currentThread().getName() + "�õ���������");
			for (int i = 0; i < 100; i += 10) {
				meters = meters - 10;

				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {

					e.printStackTrace();
				}
				System.out.println(Thread.currentThread().getName() + "����" + (i + 10) + "�ף����У�" + meters + "�ף�");

			}
		}
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		RunThread rt = new RunThread();
		for (int i = 0; i < 5; i++) {
			new Thread(rt, (i + 1) + "��ѡ��").start();
		}
	}
}
