package cn.wdw;

public class RunThread implements Runnable{
private int meters=1000;//�ܳ�1000��
//
	@Override
	public void run() {//synchronized:�߳���
		while(true){
			synchronized(this){
				if (meters<100) {
					break;
				}
				System.out.println(Thread.currentThread().getName()+"�õ�������");
				for (int i = 0; i <100; i=i+10) {
					
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
					
						e.printStackTrace();
					}
					System.out.println(Thread.currentThread().getName()+"����"+(i+10)+"��");
				}
			}
			meters-=100;
			break;
		}
		
	}
	//����
public static void main(String[] args) {
	RunThread gt=new RunThread ();
//	Thread t1 = new Thread(gt, "1��ѡ��");
//	Thread t2 = new Thread(gt, "2��ѡ��");
//	Thread t3 = new Thread(gt, "3��ѡ��");
//	Thread t4 = new Thread(gt, "4��ѡ��");
//	Thread t5 = new Thread(gt, "5��ѡ��");
//	t1.start();
//	t2.start();
//	t3.start();
//	t4.start();
//	t5.start();
	for (int i = 0; i <5; i++) {
		new Thread(gt,(i+1)+"��ѡ��").start();
	}
		
		}
}

