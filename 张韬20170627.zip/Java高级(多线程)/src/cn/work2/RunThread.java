package cn.work2;

public class RunThread implements Runnable {
	private int meters=1000;//����1000��
	
	@Override
	public void run() {
		while(true){
			synchronized(this){
				if(meters<=100){
					break;
				}
				System.out.println(Thread.currentThread().getName()+"�õ�������");
				for(int i=0;i<100;i+=10){
				try{
					Thread.sleep(1000);
				}catch(InterruptedException e){
					e.printStackTrace();
				}
				System.out.println(Thread.currentThread().getName()+"����"+(i+1)+"��!");
				}
				meters-=100;
			}
		}
	}
}
