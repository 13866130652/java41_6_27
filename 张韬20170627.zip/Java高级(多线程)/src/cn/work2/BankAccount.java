package cn.work2;

public class BankAccount {
	// ���
	private int balance = 500;

	// ��ѯ
	public int getBalance() {
		return balance;
	}

	// ȡ��
	public void withdraw(int amount) {
		balance = balance - amount;
	}

	// ���
	public void deposit(int amount) {
		balance = balance + amount;
	}
}
