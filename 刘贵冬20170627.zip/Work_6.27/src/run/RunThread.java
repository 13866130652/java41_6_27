package run;

public class RunThread implements Runnable {
	private int lang = 1000;// �ܳ�1000��

	@Override
	public void run() {
		while (true) {
			if (!running()) {
				break;
			}
			try {
				Thread.sleep(10);// Ъ��
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public synchronized boolean running() {
		if (lang > 0) {
			System.out.println(Thread.currentThread().getName() + "ѡ���õ��˽�������");
			for (int i = 0; i < 10; i++) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println(Thread.currentThread().getName() + "ѡ������" + ((i + 1) * 10) + "�ף�");
			}
			lang -= 100;
			System.out.println("����" + lang + "�ף�");
			return true;
		} else {
			return false;
		}
	}

	public static void main(String[] args) {
		RunThread rt = new RunThread();
		Thread t1 = new Thread(rt, "1��");
		Thread t2 = new Thread(rt, "2��");
		Thread t3 = new Thread(rt, "3��");
		Thread t4 = new Thread(rt, "4��");
		Thread t5 = new Thread(rt, "5��");
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
	}
}
