package ticket;

public class GetTicket implements Runnable {
	private int TicketNum = 10;// һ����10��Ʊ
	private int count = 0;// ���ĵڼ���Ʊ����

/*	public void run() {
		while (true) {
			synchronized (this) {
				if (!sell()) {
					break;
				}
			}
			System.out.println(Thread.currentThread().getName());
		}
	}*/

	public void run() {
		while (true) {
			if (!sell()) {
				break;
			}
			if (Thread.currentThread().getName().equals("��ţ��")) {
				break;
			}
		}
	}

	synchronized public boolean sell() {
		if (TicketNum <= 0) {
			return false;
		}
		count++;
		TicketNum--;
		System.out.println(Thread.currentThread().getName()//
				+ "���˵�" + count + "��Ʊ����ʣ��" + (TicketNum) + "��Ʊ");
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return true;
	}

	public static void main(String[] args) {
		GetTicket gt = new GetTicket();
		Thread t1 = new Thread(gt, "������");
		Thread t2 = new Thread(gt, "��ƱƱ");
		Thread t3 = new Thread(gt, "��ţ��");
		t1.start();
		t2.start();
		t3.start();
	}
}
