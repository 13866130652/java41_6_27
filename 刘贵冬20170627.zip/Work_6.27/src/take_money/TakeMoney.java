package take_money;

public class TakeMoney implements Runnable {
	private int balance = 500;// ���

	@Override
	public void run() {
		for (int i = 0; takeMoney(100) && i < 5; i++) {
		}
	}

	public synchronized boolean takeMoney(int amount) {
		System.out.println(Thread.currentThread().getName() + "׼��ȡ��");
		if (balance >= amount) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			balance -= amount;
			System.out.println(Thread.currentThread().getName() + "���ȡ��");
			System.out.println("���Ϊ��" + balance + "Ԫ");
			return true;
		} else {
			System.out.println("������֧��" + Thread.currentThread().getName() + "��ȡ����Ϊ��" + balance + "Ԫ");
			return false;
		}
	}

	public static void main(String[] args) {
		TakeMoney takeMoney = new TakeMoney();
		Thread t1 = new Thread(takeMoney, "����");
		Thread t2 = new Thread(takeMoney, "����������");
		t1.start();
		t2.start();
	}

}
