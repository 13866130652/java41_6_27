package wkx20170627;

public class Bank implements Runnable {
	private Double fund = 500.0;

	public static void main(String[] args) {
		Bank bank = new Bank();
		Thread th1 = new Thread(bank, "����");
		Thread th2 = new Thread(bank, "����������");
		th1.start();
		th2.start();
	}

	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			synchronized (this) {
				if (fund >= 100) {
					System.out.println(Thread.currentThread().getName() + "׼��ȡ��");
					System.out.println(Thread.currentThread().getName() + "���ȡ��");
					fund -= 100;
					// System.out.println(fund);
				} else {
					System.out.println("������֧��" + Thread.currentThread().getName() + "��ȡ��,���Ϊ" + fund);
				}
			}
		}

	}

}
