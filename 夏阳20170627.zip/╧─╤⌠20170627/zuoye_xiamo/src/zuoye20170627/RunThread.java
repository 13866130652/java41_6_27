package zuoye20170627;

//������
public class RunThread implements Runnable {
	private int meters = 1000;// ��¼�����ܳ���

	public void run() {
		while (true) {
			synchronized (this) {
				if (meters <= 100) {
					break;
				}
				System.out.println(Thread.currentThread().getName() + "�õ���������");
				for (int i = 0; i < 100; i += 10) {
					try {
						Thread.sleep(100);
					} catch (Exception e) {
						e.printStackTrace();
					}
					System.out.println(Thread.currentThread().getName() + "����" + (i + 10) + "�ף�");
				}
			}
			meters -= 100;
		}
	}

	public static void main(String[] args) {
		RunThread xm = new RunThread();
		// Thread cd = new Thread(xm, "1��ѡ��");
		// Thread cd1 = new Thread(xm, "2��ѡ��");
		// Thread cd2 = new Thread(xm, "3��ѡ��");
		// cd.start();
		// cd1.start();
		// cd2.start();
		for (int j = 0; j < 5; j++) {
			Thread cd = new Thread(xm, (j + 1) + "��ѡ��");
			cd.start();
		}
	}
}
