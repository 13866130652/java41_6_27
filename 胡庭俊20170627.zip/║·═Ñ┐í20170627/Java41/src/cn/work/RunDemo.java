package cn.work;
//��1000��
public class RunDemo implements Runnable {
	private int lenght = 1000;

	@Override
	public void run() {
		while (lenght >= 0) {
			synchronized (this) {
				System.out.println(Thread.currentThread().getName() + "�õ�������" );
				for (int i = 10; i <= 100; i += 10) {
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println(Thread.currentThread().getName() + "����" + i + "��");
				}
				lenght -= 100;
				break;
			}
		}
	}

	public static void main(String[] args) {
		RunDemo rd = new RunDemo();
		for (int i = 0; i < 10; i++) {
			new Thread(rd, ("��" + (i + 1) + "��ѡ��")).start();
			//ʹ�䰴˳�����
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
