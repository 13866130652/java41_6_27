package cn.task0627;

public class GetMoneyTest {

	public static void main(String[] args) {
		GetMoney m = new GetMoney();
		Thread th = new Thread(m, "����");
		Thread th1 = new Thread(m, "����ϼ");
		th.start();
		th1.start();
	}

}
