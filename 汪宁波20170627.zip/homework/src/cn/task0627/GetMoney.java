package cn.task0627;

public class GetMoney implements Runnable {
	private double money = 500;
	private boolean flag = false;

	@Override
	public void run() {
		while (!flag) {
			getMoney();
		}
	}

	public synchronized void getMoney() {
		if (money < 100) {
			System.out.println("������֧��" + Thread.currentThread().getName() + "��ȡ����Ϊ" + money);
			flag = true;
			return;
		}
		System.out.println(Thread.currentThread().getName() + "׼��ȡ��");
		try {
			money -= 100;
			Thread.sleep(500);// �����ӳ�0.5s
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName() + "���ȡ��");
	}

}
