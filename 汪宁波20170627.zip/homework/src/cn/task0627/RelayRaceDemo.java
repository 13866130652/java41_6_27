package cn.task0627;

public class RelayRaceDemo {

	public static void main(String[] args) {
		RelayRace r = new RelayRace();
		Thread tr1 = new Thread(r, "����");
		Thread tr2 = new Thread(r, "����ϼ");
		Thread tr3 = new Thread(r, "�����");
		Thread tr4 = new Thread(r, "��С��");
		tr1.start();
		tr2.start();
		tr3.start();
		tr4.start();
	}

}
