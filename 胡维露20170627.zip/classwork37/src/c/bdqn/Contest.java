package c.bdqn;

public class Contest implements Runnable {
	private int meters;// �ܹ�Ҫ�ܶ�����

	public Contest(int meters) {
		this.meters = meters;
	}

	public int getMeters() {
		return meters;
	}

	public void setMeters(int meters) {
		this.meters = meters;
	}

	@Override
	public void run() {
		while (true) {
			if (meters <= 100) {
				break;
			}
			synchronized (this) {
				System.out
						.println(Thread.currentThread().getName() + "�õ��˽�����!");

				for (int i = 1; i <= 10; i++) {
					try {
						Thread.sleep(100);
					} catch (Exception e) {
						e.printStackTrace();
					}
					System.out.println(Thread.currentThread().getName() + "����"
							+ (10 * i) + "�ף�");
				}
				meters -= 100;
				break;// ��֤ÿ��ֻ��һ��
			}
		}

	}

	public static void main(String[] args) {
		Contest c = new Contest(1000);
		for (int i = 1; i <= 10; i++) {
			new Thread(c, i + "��ѡ��").start();

		}

	}

}
