package c.bdqn;

public class Account implements Runnable {
	private int money;// �ܹ��ж���Ǯ
	private int num1 = 5;
	private int num2 = 5;

	public Account(int money) {
		this.money = money;
	}

	public int getMeters() {
		return money;
	}

	public void setMeters(int money) {
		this.money = money;
	}

	@Override
	public void run() {
		while (true) {
			if (Thread.currentThread().getName().equals("��������")) {
				num1--;
				if (num1 < 0) {
					break;
				}
			}
			if (Thread.currentThread().getName().equals("����")) {
				num2--;
				if (num2 < 0) {
					break;
				}
			}
			synchronized (this) {

				System.out.println(Thread.currentThread().getName() + "׼��ȡ�");
				if (money > 0) {
					System.out.println(Thread.currentThread().getName()
							+ "ȡ��100Ԫ��");
				} else {
					System.out.println("�����޷�ȡ�");
				}
				try {
					Thread.sleep(100);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			money -= 100;
		}

	}

	public static void main(String[] args) {
		Account a = new Account(500);// �˻����ֻ��500
		Thread t1 = new Thread(a, "��������");
		Thread t2 = new Thread(a, "����");
		t1.start();
		t2.start();

	}

}
