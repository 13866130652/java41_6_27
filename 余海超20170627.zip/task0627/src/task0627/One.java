package task0627;

public class One implements Runnable {
	private double balance;// ���
	private int num;// ȡ�����

	@Override
	public void run() {
		for (int i = 1; i <= num; i++) {
			synchronized (this) {
				System.out.println(Thread.currentThread().getName() + "׼��ȡ��");
				try {
					Thread.sleep(1000);// ����
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (balance >= 100) {
					System.out.println(Thread.currentThread().getName() + "���ȡ��");
					balance -= 100;
				} else {
					System.out.println("������֧��" + Thread.currentThread().getName() + "��ȡ��,���Ϊ" + balance);
				}
			}
			try {
				Thread.sleep(1000);// ����
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	// set��get����
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	// ���췽��
	public One(double balance, int num) {
		this.balance = balance;
		this.num = num;
	}

}
