package task0627;

public class TestTwo {

	public static void main(String[] args) {
		Two t = new Two();
		for (int i = 1; i <= 5; i++) {
			new Thread(t, i + "��ѡ��").start();
		}
	}

}
