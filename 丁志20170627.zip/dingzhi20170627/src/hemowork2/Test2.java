package hemowork2;

public class Test2 {
	public static void main(String[] args) {
		Access access = new Access();
		Thread man = new Thread(access);
		Thread woman = new Thread(access);
		man.setName("����");
		man.start();
		woman.setName("����������");
		woman.start();

	}
}
