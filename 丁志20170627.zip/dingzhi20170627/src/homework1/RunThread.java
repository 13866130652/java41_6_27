package homework1;

public class RunThread implements Runnable {
	private int meters = 1000;// ����100��

	public void run() {
		while (true) {
			synchronized (this) {
				if (meters <= 0) {
					break;
				}
				System.out.println(Thread.currentThread().getName() + "�õ�������!");
				for (int i = 0; i < 100; i += 10) {
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println(Thread.currentThread().getName() + "����" + (i + 10) + "��!");
				}
				meters -= 100;
			}
		}
	}
}
