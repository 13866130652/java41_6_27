package cn.dqs;

public class RunThread implements Runnable {
	private int meters = 1000;// ����1000��

	@Override
	public void run() {
		while (true) {
			synchronized (this) {
				if (meters <= 100) {
					break;
				}
				System.out.println(Thread.currentThread().getName() + "�õ���������");
				for (int i = 0; i < 100; i += 10) {
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println(Thread.currentThread().getName() + "����" + (i + 10) + "�ף�");
				}
				meters -= 100;
			}
		}
	}
}
