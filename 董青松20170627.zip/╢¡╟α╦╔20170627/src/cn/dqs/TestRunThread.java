package cn.dqs;

public class TestRunThread {

	public static void main(String[] args) {
		RunThread run = new RunThread();
		Thread s1 = new Thread(run, "NaNa");
		Thread s2 = new Thread(run, "Marry");
		Thread s3 = new Thread(run, "Lily");
		Thread s4 = new Thread(run, "Lucy");
		Thread s5 = new Thread(run, "David");
		s1.start();
		s2.start();
		s3.start();
		s4.start();
		s5.start();
	}

}
