package cn.dpp;

public class RunThread implements Runnable {
	private int meters = 500;// ȫ��1000��
	private boolean flag = false;// ����Ƿ�����

	// @Override
	// public void run() {
	// while (true) {
	// if (meters <= 0) {
	// break;
	// }
	// meters -= 100;
	// synchronized (this) {
	// System.out.println(Thread.currentThread().getName() + "�õ��˽�������");
	// int num = 0;
	// for (int i = 0; i < 10; i++) {
	// try {
	// Thread.sleep(100);
	// } catch (InterruptedException e) {
	// e.printStackTrace();
	// }
	// num += 10;
	// System.out.println(Thread.currentThread().getName() + "����" + num + "�ף�");
	// }
	// }
	// }
	// }

	@Override
	public void run() {
		while (!flag) {
			go();
		}
	}

	synchronized public void go() {
		if (meters <= 0) {
			flag = true;
		} else {
			int num = 0;// ���˶�����
			System.out.println(Thread.currentThread().getName() + "�õ���������");
			for (int i = 0; i < 10; i++) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				num += 10;
				System.out.println(Thread.currentThread().getName() + "����" + num + "�ף�");
			}
			meters -= 100;
		}

	}

	public static void main(String[] args) {
		RunThread r = new RunThread();
		for (int i = 0; i < 3; i++) {
			Thread t = new Thread(r, (i + 1) + "��ѡ��");
			t.start();
		}
	}

}
